//
//  MusicPlayerViewController.swift
//  Walker
//
//  Created by ODoganY on 23/12/14.
//  Copyright (c) 2014 osdoyi. All rights reserved.
//

import UIKit

class MusicPlayerViewController: UIViewController {
    
    
    
}